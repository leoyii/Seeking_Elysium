Game: Seeking Elysium
Company Name: Rito Games
Project Lead: Glen Lin
Project Member: Leo Yi
Age Group: 12-15

Surviving Addictions

Purpose of game: This game is intended to help educate children about addiction. It illustrates and puts into perspective the impact of addiction on people’s lives and how it can ruin lives. It also teaches how to deal with addiction and ways to recover from it and get treatment for it.

Notes: 
To run the program, open the Seeking_Elysium.jar file
Make sure java/jdk-17 or 8 is installed on operating device.

Controls and Instructions:

At any point in the game past the main menu, you can press 'esc' key to pause the game and a pause menu will appear.

Level 1 Instructions: Use arrow keys by holding and releasing (up arrow to move up, down arrow to move down, left arrow to move left, and right arrow to move right). Walk near the objects in the room until they glow yellow. Once they have a yellow border, you can press the 'e' key to interact with the object. 

Level 2 Instructions: Press the arrow keys (tap) to move up, down, left, right to move the character to the next visible grid of the maze. Press e to interact with the clues on the ground scattered around the maze. The clues will help you to figure out the password to leave the maze.

Level 3 Instructions: Press the attack button to open a prompt of a question. If you choose the correct answer, you will deal damage to the boss enemy. After each attack, the boss will deal a random amount of damage between a certain range to you. The game ends when your player HP hits 0, the boss HP hits 0, or if you press the 'give up' button.